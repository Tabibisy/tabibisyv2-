export function initVitals(){
    const btn = document.getElementById('vitalsBtn');
    const modal = document.getElementById('vitalsModal');
    btn.onclick = ()=>modal.showModal();
    closeVitals.onclick = ()=>modal.close();
    saveVitals.onclick = ()=>modal.close();
}
