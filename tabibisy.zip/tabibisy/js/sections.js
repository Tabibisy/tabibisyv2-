export const sections = [
{
    title:"الملف الشخصي",
    html:`
    <label>الاسم<input name="name" required></label>
    <label>الجنس<select name="gender"><option>ذكر</option><option>أنثى</option></select></label>
    <label>العمر<input type="number" name="age" required></label>
    <label>الحالة الاجتماعية
        <select name="status" onchange="kidsRow.style.display=this.value==='أعزب'?'none':'block'">
            <option>أعزب</option><option>متزوج</option><option>مطلق</option><option>أرمل</option>
        </select>
    </label>
    <div id="kidsRow" style="display:none">
        <label>عدد الأولاد<input type="number" name="kids"></label>
    </div>
    <label>عنوان السكن<input name="address"></label>
    <label>المهنة<input name="job"></label>`
},
{
    title:"الشكاية الرئيسية",
    html:`
    <div id="complaints"></div>
    <button type="button" onclick="addComplaint()">+ إضافة عرض</button>`
},
{
    title:"السوابق المرضية",
    html:`
    <label><input type="checkbox" name="past[]" value="لايوجد"> لايوجد</label>
    <label><input type="checkbox" name="past[]" value="سكري"> السكري</label>
    <label><input type="checkbox" name="past[]" value="ضغط"> فرط ضغط الدم</label>
    <label><input type="checkbox" name="past[]" value="ربو"> الربو</label>
    <label>أخرى<input name="past_other"></label>`
},
{
    title:"السوابق الجراحية",
    html:`
    <label><input type="checkbox" name="surg[]" value="لايوجد"> لايوجد</label>
    <label><input type="checkbox" name="surg[]" value="زائدة"> استئصال الزائدة</label>
    <label><input type="checkbox" name="surg[]" value="مرارة"> المرارة</label>
    <label>أخرى<input name="surg_other"></label>`
},
{
    title:"الأدوية الحالية",
    html:`
    <div id="drugs"></div>
    <button type="button" onclick="addDrug()">+ إضافة دواء</button>`
},
{
    title:"الحساسية",
    html:`
    <div id="allergies"></div>
    <button type="button" onclick="addAllergy()">+ إضافة حساسية</button>`
},
{
    title:"السوابق العائلية والعادات",
    html:`
    <label>هل يوجد أمراض وراثية في العائلة؟<input name="family"></label>
    <label>التدخين<select name="smoking"><option>لا</option><option>نعم</option></select></label>
    <label>الكحول<select name="alcohol"><option>لا</option><option>نعم</option></select></label>
    `
}
];

// وظائف تفاعلية للشكايات
window.addComplaint = ()=>{
    const idx = document.querySelectorAll('.complaint').length;
    const div = document.createElement('div');
    div.className='complaint';
    div.innerHTML = `
        <input name="comp[${idx}][name]" placeholder="العرض">
        <label><input type="checkbox" onchange="toggleDetail(this,${idx})"> أضف تفاصيل</label>
        <div id="det${idx}" style="display:none">
            <label>طبيعة الألم<input name="comp[${idx}][nature]"></label>
            <label>الموقع<input name="comp[${idx}][site]"></label>
            <label>الانتشار<input name="comp[${idx}][radiation]"></label>
            <label>الصفة<input name="comp[${idx}][quality]"></label>
            <label>الشدة<input type="range" min="0" max="10" name="comp[${idx}][severity]"></label>
            <label>المدة<input name="comp[${idx}][duration]"></label>
            <label>عوامل مفاقمة<input name="comp[${idx}][agg]"></label>
            <label>عوامل مخففة<input name="comp[${idx}][rel]"></label>
        </div>
    `;
    document.getElementById('complaints').appendChild(div);
};
window.toggleDetail=(cb,idx)=>document.getElementById('det'+idx).style.display=cb.checked?'block':'none';

window.addDrug = ()=>{
    const d=document.createElement('div');
    d.innerHTML='<input name="drugs[]" list="drugList" placeholder="اسم الدواء"><datalist id="drugList"><option>باراسيتامول</option><option>أدفيل</option></datalist>';
    document.getElementById('drugs').appendChild(d);
};
window.addAllergy = ()=>{
    const d=document.createElement('div');
    d.innerHTML='<input name="allergy[]" placeholder="مثلاً بنسلين">';
    document.getElementById('allergies').appendChild(d);
};
