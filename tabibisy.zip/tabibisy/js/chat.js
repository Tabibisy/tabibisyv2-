export function initChat(){
    const fab = document.getElementById('chatFab');
    const modal = document.getElementById('chatModal');
    const box = document.getElementById('chatBox');
    const inp = document.getElementById('chatInput');
    fab.onclick = ()=>modal.showModal();
    closeChat.onclick = ()=>modal.close();
    sendChat.onclick = async ()=>{
        const q = inp.value;
        if(!q) return;
        box.innerHTML+=`<div>أنت: ${q}</div>`;
        inp.value='';
        const res = await fetch(GEMINI_URL,{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({contents:[{parts:[{text:q}]}]})
        });
        const json = await res.json();
        const a = json.candidates[0].content.parts[0].text;
        box.innerHTML+=`<div>Gemini: ${a}</div>`;
        box.scrollTop = box.scrollHeight;
    };
}
