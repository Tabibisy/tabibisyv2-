export function downloadPdf(el){
    const doc = new jspdf.jsPDF({orientation:'p',unit:'mm',format:'a4'});
    doc.setFont('Cairo');
    doc.text(5,10,el.innerText,{lang:'ar'});
    doc.save('تقرير-سريري.pdf');
}
