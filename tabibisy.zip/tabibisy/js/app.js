const GEMINI_API_KEY = 'ضع_مفتاحك_هنا'; // <==== أضف مفتاحك
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

import { sections } from './sections.js';
import { initVitals } from './vitals.js';
import { downloadPdf } from './pdfExport.js';
import { initChat } from './chat.js';

let current = 0;
const form = document.getElementById('storyForm');
const progress = document.querySelector('#progressBar div');
const reportPage = document.getElementById('reportPage');

// التحقق من الاتصال
fetch(GEMINI_URL.replace('generateContent',''),{mode:'no-cors'})
  .then(()=>connStatus.textContent='متصل')
  .catch(()=>connStatus.textContent='فشل الاتصال');

// رسم الأقسام
form.innerHTML = sections.map((sec,i)=>`
    <div class="section" data-idx="${i}">
        <h2>${sec.title}</h2>
        ${sec.html}
    </div>`).join('');
const allSections = document.querySelectorAll('.section');
allSections[0].classList.add('active');

// التنقل
function show(idx){
    allSections[current].classList.remove('active');
    allSections[idx].classList.add('active');
    current=idx;
    prevBtn.disabled = !current;
    nextBtn.classList.toggle('hidden', current===sections.length-1);
    finishBtn.classList.toggle('hidden', current!==sections.length-1);
    progress.style.width = ((current+1)/sections.length*100)+'%';
}
prevBtn.onclick=()=>show(current-1);
nextBtn.onclick=()=>show(current+1);

// إنهاء القصة
finishBtn.onclick = async ()=>{
    const data = Object.fromEntries(new FormData(form));
    const prompt = `أنت طبيب خبير. أنشئ تقريراً سريرياً كاملاً بالعربية بناءً على البيانات التالية: ${JSON.stringify(data)}`;
    const res = await fetch(GEMINI_URL,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})
    });
    const json = await res.json();
    const report = json.candidates[0].content.parts[0].text;
    document.getElementById('reportContent').innerText = report;
    reportPage.classList.remove('hidden');
    form.parentElement.classList.add('hidden');
};

// الوضع الليلي
toggleTheme.onclick = ()=>{
    darkTheme.disabled = !darkTheme.disabled;
    localStorage.setItem('dark',!darkTheme.disabled);
};
if(localStorage.getItem('dark')==='true') darkTheme.disabled=false;

// تهيئة المكوّنات
initVitals();
initChat();
window.downloadPdf = ()=>downloadPdf(reportContent);
